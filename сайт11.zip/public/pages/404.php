<?
    if(!defined("HackChik")) return require_once '../../../public/pages/404.php';
?>
<br><td class="middel">
	<div class="box">
		<div class="boxtitle">Ошибка</div>
		<h4>Not Found (#404)</h4>
	Страница не найдена. 
	</div>
</td>