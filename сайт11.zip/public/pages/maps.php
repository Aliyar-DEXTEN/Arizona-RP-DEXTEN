<main class="min-h-screen">
	<div class="Toastify"></div>
	<section class="maps_section__Rzvvl">
		<div class="maps_container___ph3b container_container__ilA55">
			<header class="mapsSection_header__8_2fr">
				<h1 class="mapsSection_title__qtMPq">Карта</h1>
				<button type="button" class="button_download_transparent__DjOus mapsSection_back__HXwnq">
					<span class="">Назад</span>
				</button>
			</header>
			<div class="mapsSection_wrapper__9OUQu">
				<div class="mapsSection_select_wrapper__We_rp">
					<div class="form_label__cWZkH mapsSection_select__PwzIY">
						<h4 class="form_label_title__cL0ZW">Сервер</h4>
						<button class="form_form_select__DoLc0" type="button"></button>
						<span class="form_error__3VdLo"></span>
						<div class="form_options_wrapper__7ggYk">
							<ul class="form_options__B22ns"></ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>