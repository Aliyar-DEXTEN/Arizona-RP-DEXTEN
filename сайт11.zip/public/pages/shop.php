<main class="min-h-screen">
	<div class="Toastify"></div>
	<section class="shop_section__r5mUx">
		<img alt="background" loading="lazy" width="3456" height="4564" decoding="async" data-nimg="1" class="shop_bg__ben0s" style="color:transparent" src="_next/static/media/background.c9472257.webp"/>
		<div class="shopCards_container__vPb0J container_container__ilA55">
			<header class="shopCards_header__s1bV5">
				<h2 class="shopCards_title__OEPZa">Магазин</h2>
			</header>
			<div class="tab_wrapper__pQbuP">
				<div class="tab_tab__yVPqF">
					<ul class="tab_tab_row__ad7iD">
						<li>
							<button type="button" class="tab_tab_button__67NNQ tab_tab_button_active__eT8bB">
								<span class="">Главная</span>
							</button>
						</li>
						<li>
							<button type="button" class="tab_tab_button__67NNQ tab_tab_button_vip__E5SGw">
								<span class="">VIP</span>
							</button>
						</li>
						<li>
							<button type="button" class="tab_tab_button__67NNQ">
								<span class="">Скины</span>
							</button>
						</li>
						<li>
							<button type="button" class="tab_tab_button__67NNQ">
								<span class="">Машины</span>
							</button>
						</li>
						<li>
							<button type="button" class="tab_tab_button__67NNQ">
								<span class="">Аксессуары</span>
							</button>
						</li>
						<li>
							<button type="button" class="tab_tab_button__67NNQ">
								<span class="">Охрана</span>
							</button>
						</li>
						<li>
							<button type="button" class="tab_tab_button__67NNQ">
								<span class="">Навыки</span>
							</button>
						</li>
						<li>
							<button type="button" class="tab_tab_button__67NNQ">
								<span class="">Остальное</span>
							</button>
						</li>
					</ul>
					<div class="tab_active_row__342dL" style="transform:translateX(0px);width:0">
						<button class="tab_active__gHZh7">
							<span class="tab_visible__lECY8">Главная</span>
							<span class="tab_visible_vip__4VVUw">VIP</span>
							<span class="">Скины</span>
							<span class="">Машины</span>
							<span class="">Аксессуары</span>
							<span class="">Охрана</span>
							<span class="">Навыки</span>
							<span class="">Остальное</span>
						</button>
					</div>
				</div>
			</div>
			<section class="shopPopup_layout__aUg48 shopPopup_hidden_layout__br8o3">
				<div class="shopPopup_container__V3H_e shopPopup_hidden__I_NVI container_container__ilA55"></div>
			</section>
			<ul class="cards_row__kyH69">
				<div class="preload_main__Jjbnu cards_card__jPGhx cards_preloader__Aafai"></div>
				<div class="preload_main__Jjbnu cards_card__jPGhx cards_preloader__Aafai"></div>
				<div class="preload_main__Jjbnu cards_card__jPGhx cards_preloader__Aafai"></div>
				<div class="preload_main__Jjbnu cards_card__jPGhx cards_preloader__Aafai"></div>
				<div class="preload_main__Jjbnu cards_card__jPGhx cards_preloader__Aafai"></div>
				<div class="preload_main__Jjbnu cards_card__jPGhx cards_preloader__Aafai"></div>
				<div class="preload_main__Jjbnu cards_card__jPGhx cards_preloader__Aafai"></div>
				<div class="preload_main__Jjbnu cards_card__jPGhx cards_preloader__Aafai"></div>
			</ul>
		</div>
	</section>
</main>