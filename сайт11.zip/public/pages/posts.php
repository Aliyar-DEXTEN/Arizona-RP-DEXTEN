<main class="min-h-screen">
                <div class="Toastify"></div>
                <section class="news_section__TvJFL">
                    <div class="news_container__R3RPA container_container__ilA55">
                        <header class="newsSection_header___Hv7z">
                            <div class="newsSection_header_main__k5XmD">
                                <h1 class="newsSection_title__c4LQg">Новость</h1>
                                <span class="newsSection_subtitle__1XrcX">Дата</span>
                            </div>
                            <button type="button" class="button_download_transparent__DjOus newsSection_back__YjZvU">
                                <span class="">Назад</span>
                            </button>
                        </header>
                        <div class="newsSection_wrapper__nT_hl">
                            <div class="preload_main__Jjbnu newsSection_image__KdLdE"></div>
                        </div>
                    </div>
                </section>
            </main>