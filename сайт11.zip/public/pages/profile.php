<main class="min-h-screen">
	<div class="Toastify"></div>
	<section class="profile_section__NPoHn">
		<div class="profile_container__BOaLM container_container__ilA55">
			<div class="popupLayout_layout__wznbS popupLayout_hidden_layout__7Is8J">
				<div class="popupLayout_wrapper__Adjr4">
					<div class="popupLayout_container__h9myb popupLayout_hidden__dfr9q container_container__ilA55"></div>
				</div>
			</div>
			<div class="popupLayout_layout__wznbS popupLayout_hidden_layout__7Is8J">
				<div class="popupLayout_wrapper__Adjr4">
					<div class="popupLayout_container__h9myb popupLayout_hidden__dfr9q container_container__ilA55"></div>
				</div>
			</div>
			<header class="profileContent_header__CMddG">
				<h1 class="profileContent_title__xQI0y">Профиль</h1>
				<span class="profileContent_server__pqn_e">Сервер: </span>
			</header>
			<div class="profileContent_row__MN1a6">
				<aside class="aside_aside__N1JRg">
					<menu class="aside_menu__PzkgY">
						<div class="preload_main__Jjbnu"></div>
					</menu>
					<div class="aside_shop__nO99R">
						<div class="aside_shop_image__682hR">
							<img alt="shop" loading="lazy" decoding="async" data-nimg="fill" style="position:absolute;height:100%;width:100%;left:0;top:0;right:0;bottom:0;color:transparent" src="/_next/static/media/shop.5fcf00d4.png"/>
						</div>
						<span class="aside_shop_title__kWQ6H">
							Магазин <br class="aside_separator__TknSu"/>игровой валюты
						</span>
						<button type="button" class="button_big_white__le1NQ aside_shop_button__xTd5s">
							<span class="">Купить</span>
						</button>
					</div>
				</aside>
				<div class="profileContent_content__leMdn">
					<div class="profileContent_slide__NABBV profileContent_active__slYit">
						<section class="main_main__hUplq">
							<div class="main_top__DNEDD">
								<div class="user_user__uXAt_">
									<div class="user_user_row__7n0ed">
										<div class="user_avatar__L6eUq"></div>
										<div class="user_info__464yG">
											<header class="user_header__ts928">
												<div class="user_avatar__L6eUq user_avatar_mobile__MSrnP"></div>
												<div>
													<div class="user_header_top__CuEIX">
														<h3 class="user_header_title__KOpop"></h3>
														<div class="user_header_right__YmLJE">
															<span class="user_level__Zd7_h">undefinedlvl</span>
															<span class="user_coins__nDof0">undefinedAZ</span>
														</div>
													</div>
													<span class="user_option__lCBSW"></span>
												</div>
											</header>
											<div class="user_bottom__CLnhv">
												<dl class="user_char___I6ZL">
													<div class="user_char_row__9gPXH">
														<dt class="user_option__lCBSW">Здоровье</dt>
														<dd class="user_value__ASjUe">
															<div class="charLine_wrapper__wsG5c">
																<span class="charLine_values__BC593">/ </span>
																<span class="charLine_hp__IkqRO" style="transform:translateX(-NaN%) skewX(-15deg)"></span>
															</div>
														</dd>
													</div>
													<div class="user_char_row__9gPXH">
														<dt class="user_option__lCBSW">Голод</dt>
														<dd class="user_value__ASjUe">
															<div class="charLine_wrapper__wsG5c">
																<span class="charLine_values__BC593">/ </span>
																<span class="charLine_hunger__wb4Ao" style="transform:translateX(-NaN%) skewX(-15deg)"></span>
															</div>
														</dd>
													</div>
												</dl>
												<div class="user_bottom_right__caZd1">
													<div class="user_header_right__YmLJE user_header_right_mobile__HrUF_">
														<span class="user_level__Zd7_h">undefinedlvl</span>
														<span class="user_coins__nDof0">undefinedAZ</span>
													</div>
													<button class="user_person__hELLF">
														<img alt="to_person" loading="lazy" decoding="async" data-nimg="fill" style="position:absolute;height:100%;width:100%;left:0;top:0;right:0;bottom:0;color:transparent" src="/_next/static/media/slide_right.d63ee92d.svg"/>
													</button>
												</div>
											</div>
										</div>
									</div>
									<div class="preload_main__Jjbnu"></div>
								</div>
							</div>
							<div class="main_bottom__46Os7">
								<div class="rating_rating__jUSr6">
									<div>
										<h3 class="rating_title__9cG0b">Рейтинги</h3>
										<dl class="rating_top__iV2DZ">
											<dt class="rating_option__m2Xvu">
												<div class="rating_option_inner__oGdHq">
													<span>Самый богатый</span>
													<span class="rating_value_mobile__6JlTa"></span>
												</div>
												<div class="rating_option_inner__oGdHq">
													<span>Высокий уровень</span>
													<span class="rating_value_mobile__6JlTa"></span>
												</div>
											</dt>
											<dd class="rating_value____niy">
												<span></span>
												<span></span>
											</dd>
										</dl>
										<button type="button" class="button_gray__CFHKA">
											<span class="">Смотреть список</span>
										</button>
									</div>
								</div>
								<div class="security_security__25OP3">
									<div>
										<h3 class="security_title__5XgFM">Безопасность</h3>
										<dl class="security_top__hV3VG">
											<dt class="security_option__CG0pH">
												<div class="security_option_inner__m7jtD">
													<span>Почта</span>
													<span class="security_value_mobile__nXdpK"></span>
												</div>
												<div class="security_option_inner__m7jtD">
													<span>Пароль</span>
													<span class="security_value_mobile__nXdpK">******</span>
												</div>
											</dt>
											<dd class="security_value__TVtZF">
												<span></span>
												<span>******</span>
											</dd>
										</dl>
										<div class="security_buttons__lKdmd">
											<button type="button" class="button_gray__CFHKA">
												<span class="">Редактировать</span>
											</button>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
					<div class="profileContent_slide__NABBV profileContent_next__jJUqZ"></div>
				</div>
				<div class="aside_shop__nO99R profileContent_shop__rlaif">
					<div class="aside_shop_image__682hR">
						<img alt="shop" loading="lazy" decoding="async" data-nimg="fill" style="position:absolute;height:100%;width:100%;left:0;top:0;right:0;bottom:0;color:transparent" src="_next/static/media/shop.5fcf00d4.png"/>
					</div>
					<span class="aside_shop_title__kWQ6H">
						Магазин <br class="aside_separator__TknSu"/>игровой валюты
					</span>
					<button type="button" class="button_big_white__le1NQ aside_shop_button__xTd5s">
						<span class="">Купить</span>
					</button>
				</div>
			</div>
		</div>
	</section>
</main>