<?php
if(!class_exists('Config')) {
    class Config {
        const DB_HOST = '85.193.87.122';
        const DB_USER = 'testbaze';
        const DB_PASS = 'Qwerty123123';
        const DB_NAME = 'testbaze';
    }
}

$config = array(
    'nameproject' => 'Arizona',
    'url_group_vk' => 'https://vk.com/derryt',
    'admin_name' => 'Admin',
    'donat_x' => '2',
    'email_name' => 'terryry@mail.ru',
    'smtp' => '',
    'smtp_port' => '',
    'smtp_username' => '',
    'smtp_password' => ''
);
?>