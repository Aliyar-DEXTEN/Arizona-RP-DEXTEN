(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[952], {
    5452: function(e, n, t) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/pay/[orderId]", function() {
            return t(1540)
        }
        ])
    },
    1540: function(e, n, t) {
        "use strict";
        t.r(n);
        var s = t(5893)
          , r = t(7041)
          , c = t(1163)
          , o = t(7294)
          , a = t(2920)
          , i = t(4e3)
          , l = t(7435)
          , u = t(3111);
        let _ = () => {
            let {query: e, push: n} = (0,
            c.useRouter)()
              , {setSelectedOrder: t, selectedOrder: _} = (0,
            o.useContext)(i.Il)
              , x = e => {
                if (!e) {
                    n("/");
                    return
                }
                let s = (0,
                r.getCookie)("accessToken");
                (0,
                l.co)(e, s).then(e => {
                    t(e)
                }
                ).catch(e => {
                    n("/"),
                    a.Am.error(e.message)
                }
                )
            }
            ;
            return (0,
            o.useEffect)( () => {
                let n = e.orderId;
                return !_ && n && x(n),
                () => {
                    _ && t(null)
                }
            }
            , [e, _]),
            (0,
            s.jsx)(u.$S, {})
        }
        ;
        n.default = _
    },
    3111: function(e, n, t) {
        "use strict";
        t.d(n, {
            rh: function() {
                return Z
            },
            qZ: function() {
                return C
            },
            SK: function() {
                return o
            },
            oe: function() {
                return E
            },
            Sq: function() {
                return F
            },
            $S: function() {
                return U
            },
            $r: function() {
                return L
            },
            NZ: function() {
                return b
            },
            MG: function() {
                return W
            },
            k3: function() {
                return x
            },
            Fe: function() {
                return f
            }
        });
        var s = t(5893)
          , r = t(7294)
          , c = t(242);
        let o = () => (0,
        s.jsxs)(s.Fragment, {
            children: [(0,
            s.jsx)(c.Rv, {}), (0,
            s.jsx)(c.H0, {}), (0,
            s.jsx)(c.rf, {}), (0,
            s.jsx)(c.vk, {}), (0,
            s.jsx)(c.dk, {})]
        });
        var a = t(5675)
          , i = t.n(a)
          , l = {
            src: "/_next/static/media/background.c9472257.webp",
            height: 4564,
            width: 3456,
            blurDataURL: "data:image/webp;base64,UklGRqAAAABXRUJQVlA4WAoAAAAQAAAABQAABwAAQUxQSC0AAAABYCVJkuloLZ5tm1+KiOgNjKi8MlH8R5kr/77KsquS5pnmxpHfqCVUowKkBgAAVlA4IEwAAADQAQCdASoGAAgAAkA4JbACdAD0Z5JeoAD+9Lolw1Q+kEs68lxyuXb6H9G6vQ0YpsR/xjNetf9qh46uXa+e8rX7avWGF7usKQBtAAAA",
            blurWidth: 6,
            blurHeight: 8
        }
          , u = t(4213)
          , _ = t.n(u);
        let x = () => (0,
        s.jsxs)("section", {
            className: _().section,
            children: [(0,
            s.jsx)(i(), {
                src: l,
                alt: "background",
                className: _().bg
            }), (0,
            s.jsx)(c.Qz, {})]
        });
        var d = t(1163)
          , h = t(3388)
          , m = t(3940)
          , A = t.n(m);
        let f = () => {
            let e = (0,
            d.useRouter)();
            return (0,
            s.jsxs)("section", {
                className: A().section,
                children: [(0,
                s.jsx)(i(), {
                    src: l,
                    alt: "background",
                    className: A().bg
                }), (0,
                s.jsx)(c.oI, {
                    termsList: "/document/terms" === e.pathname ? h.tG : h.ye
                })]
            })
        }
        ;
        var p = t(4269)
          , j = t(3710)
          , N = t.n(j);
        let b = () => (0,
        s.jsx)("section", {
            className: N().section,
            children: (0,
            s.jsx)(p.W2, {
                className: N().container,
                children: (0,
                s.jsx)(c.H6, {})
            })
        });
        var v = t(4e3)
          , k = t(3002)
          , w = t(5141)
          , g = t.n(w);
        let C = () => {
            let {user: e} = (0,
            r.useContext)(v.Il)
              , n = (0,
            d.useRouter)();
            return (0,
            r.useEffect)( () => {
                (null == e ? void 0 : e.role) !== k.i4.ADMIN && n.push("/profile")
            }
            , []),
            (0,
            s.jsx)("section", {
                className: g().section,
                children: (0,
                s.jsx)(p.W2, {
                    className: g().container,
                    children: (null == e ? void 0 : e.role) === k.i4.ADMIN && (0,
                    s.jsx)(c.wo, {})
                })
            })
        }
        ;
        var R = t(2517)
          , I = t.n(R);
        let E = () => (0,
        s.jsx)("section", {
            className: I().section,
            children: (0,
            s.jsx)(p.W2, {
                className: I().container,
                children: (0,
                s.jsx)(c.BT, {})
            })
        });
        var B = t(8954)
          , Q = t.n(B);
        let W = () => {
            let {user: e} = (0,
            r.useContext)(v.Il)
              , n = (0,
            d.useRouter)();
            return (0,
            r.useEffect)( () => {
                (null == e ? void 0 : e.role) !== k.i4.ADMIN && n.push("/profile")
            }
            , []),
            (0,
            s.jsx)("section", {
                className: Q().section,
                children: (0,
                s.jsx)(p.W2, {
                    className: Q().container,
                    children: (null == e ? void 0 : e.role) === k.i4.ADMIN && (0,
                    s.jsx)(c.cx, {})
                })
            })
        }
        ;
        var D = t(2920)
          , y = t(5683)
          , P = t(7435)
          , M = t(601)
          , S = t.n(M);
        let Z = e => {
            let {accounts: n, fetchUser: t, secret: c} = e
              , [o,a] = (0,
            r.useState)(!1)
              , {setPopupDataOrType: i, setSelectedForgottenPaasswordAccount: l} = (0,
            r.useContext)(v.Il)
              , {push: u} = (0,
            d.useRouter)()
              , _ = async e => {
                t && (a(!0),
                c ? (i(k.ZQ.CHANGE_FORGOTTEN_PASSWORD),
                l({
                    secret: c,
                    accountId: e.id,
                    server: e.server
                }),
                document.body.style.overflow = "hidden") : (0,
                P.bs)(e).then( () => {
                    u("/profile"),
                    t()
                }
                ).catch(e => {
                    u("/"),
                    D.Am.error(e.message)
                }
                ),
                a(!1))
            }
            ;
            return (0,
            s.jsx)("section", {
                className: S().section,
                children: (0,
                s.jsx)(p.W2, {
                    className: S().container,
                    children: n ? (0,
                    s.jsxs)("div", {
                        className: S().main,
                        children: [(0,
                        s.jsx)("h3", {
                            className: S().title,
                            children: "Выберите аккаунт"
                        }), n.map(e => (0,
                        s.jsx)(y.zx, {
                            text: e.name,
                            buttonType: k.L$.BIG_PINK,
                            className: S().button,
                            onClickButton: () => _(e),
                            loading: o
                        }, e.id))]
                    }) : (0,
                    s.jsx)(y.B0, {
                        classNames: S().loader
                    })
                })
            })
        }
        ;
        var G = t(5811)
          , H = t.n(G);
        let L = () => {
            let {user: e} = (0,
            r.useContext)(v.Il)
              , n = (0,
            d.useRouter)();
            return (0,
            r.useEffect)( () => {
                (null == e ? void 0 : e.role) !== k.i4.ADMIN && n.push("/profile")
            }
            , []),
            (0,
            s.jsx)("section", {
                className: H().section,
                children: (0,
                s.jsx)(p.W2, {
                    className: H().container,
                    children: (null == e ? void 0 : e.role) === k.i4.ADMIN && (0,
                    s.jsx)(c.xm, {})
                })
            })
        }
        ;
        var T = t(5417)
          , q = t.n(T);
        let F = () => (0,
        s.jsx)("section", {
            className: q().section,
            children: (0,
            s.jsx)(p.W2, {
                className: q().container,
                children: (0,
                s.jsx)(c.cc, {})
            })
        });
        var K = t(9135)
          , O = t.n(K);
        let U = () => (0,
        s.jsx)("section", {
            className: O().main,
            children: (0,
            s.jsx)(p.W2, {
                className: O().container,
                children: (0,
                s.jsx)(c.zu, {})
            })
        })
    },
    601: function(e) {
        e.exports = {
            section: "authCallback_section__hrxYn",
            container: "authCallback_container__Plb6q",
            loader: "authCallback_loader__ZrLnA",
            main: "authCallback_main__s8BDu",
            main_wrapper: "authCallback_main_wrapper__wrjMB",
            title: "authCallback_title__pUo0Z",
            button: "authCallback_button__mFLEw"
        }
    },
    5141: function(e) {
        e.exports = {
            section: "changeNews_section__08xtg",
            container: "changeNews_container__deEZT"
        }
    },
    2517: function(e) {
        e.exports = {
            section: "maps_section__Rzvvl",
            container: "maps_container___ph3b"
        }
    },
    5417: function(e) {
        e.exports = {
            section: "news_section__TvJFL",
            container: "news_container__R3RPA"
        }
    },
    9135: function(e) {
        e.exports = {
            main: "pay_main__qhZ8c",
            container: "pay_container__5RFrd"
        }
    },
    5811: function(e) {
        e.exports = {
            section: "payoutPanel_section__rdzdu",
            container: "payoutPanel_container__HjV5w"
        }
    },
    3710: function(e) {
        e.exports = {
            section: "profile_section__NPoHn",
            container: "profile_container__BOaLM"
        }
    },
    8954: function(e) {
        e.exports = {
            section: "serverPanel_section___6m_Q",
            container: "serverPanel_container__aWR5x"
        }
    },
    4213: function(e) {
        e.exports = {
            section: "shop_section__r5mUx",
            bg: "shop_bg__ben0s"
        }
    },
    3940: function(e) {
        e.exports = {
            section: "terms_section__RoYZs",
            bg: "terms_bg__InJ5e"
        }
    }
}, function(e) {
    e.O(0, [774, 888, 179], function() {
        return e(e.s = 5452)
    }),
    _N_E = e.O()
}
]);
