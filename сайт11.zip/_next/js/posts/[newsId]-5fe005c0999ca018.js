(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[146], {
    2762: function(e, n, t) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/posts/[newsId]", function() {
            return t(4651)
        }
        ])
    },
    4651: function(e, n, t) {
        "use strict";
        t.r(n),
        t.d(n, {
            default: function() {
                return a
            }
        });
        var s = t(5893)
          , c = t(9008)
          , r = t.n(c)
          , i = t(3388)
          , o = t(3111);
        function a() {
            return (0,
            s.jsxs)(s.Fragment, {
                children: [(0,
                s.jsxs)(r(), {
                    children: [(0,
                    s.jsx)("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }), (0,
                    s.jsx)("title", {
                        children: i.FV.change_news
                    })]
                }), (0,
                s.jsx)(o.Sq, {})]
            })
        }
    },
    3111: function(e, n, t) {
        "use strict";
        t.d(n, {
            rh: function() {
                return Z
            },
            qZ: function() {
                return C
            },
            SK: function() {
                return i
            },
            oe: function() {
                return E
            },
            Sq: function() {
                return T
            },
            $S: function() {
                return U
            },
            $r: function() {
                return G
            },
            NZ: function() {
                return b
            },
            MG: function() {
                return W
            },
            k3: function() {
                return x
            },
            Fe: function() {
                return f
            }
        });
        var s = t(5893)
          , c = t(7294)
          , r = t(242);
        let i = () => (0,
        s.jsxs)(s.Fragment, {
            children: [(0,
            s.jsx)(r.Rv, {}), (0,
            s.jsx)(r.H0, {}), (0,
            s.jsx)(r.rf, {}), (0,
            s.jsx)(r.vk, {}), (0,
            s.jsx)(r.dk, {})]
        });
        var o = t(5675)
          , a = t.n(o)
          , l = {
            src: "/media/background.c9472257.webp",
            height: 4564,
            width: 3456,
            blurDataURL: "data:image/webp;base64,UklGRqAAAABXRUJQVlA4WAoAAAAQAAAABQAABwAAQUxQSC0AAAABYCVJkuloLZ5tm1+KiOgNjKi8MlH8R5kr/77KsquS5pnmxpHfqCVUowKkBgAAVlA4IEwAAADQAQCdASoGAAgAAkA4JbACdAD0Z5JeoAD+9Lolw1Q+kEs68lxyuXb6H9G6vQ0YpsR/xjNetf9qh46uXa+e8rX7avWGF7usKQBtAAAA",
            blurWidth: 6,
            blurHeight: 8
        }
          , u = t(4213)
          , _ = t.n(u);
        let x = () => (0,
        s.jsxs)("section", {
            className: _().section,
            children: [(0,
            s.jsx)(a(), {
                src: l,
                alt: "background",
                className: _().bg
            }), (0,
            s.jsx)(r.Qz, {})]
        });
        var d = t(1163)
          , h = t(3388)
          , m = t(3940)
          , A = t.n(m);
        let f = () => {
            let e = (0,
            d.useRouter)();
            return (0,
            s.jsxs)("section", {
                className: A().section,
                children: [(0,
                s.jsx)(a(), {
                    src: l,
                    alt: "background",
                    className: A().bg
                }), (0,
                s.jsx)(r.oI, {
                    termsList: "/document/terms" === e.pathname ? h.tG : h.ye
                })]
            })
        }
        ;
        var j = t(4269)
          , p = t(3710)
          , N = t.n(p);
        let b = () => (0,
        s.jsx)("section", {
            className: N().section,
            children: (0,
            s.jsx)(j.W2, {
                className: N().container,
                children: (0,
                s.jsx)(r.H6, {})
            })
        });
        var v = t(4e3)
          , w = t(3002)
          , k = t(5141)
          , g = t.n(k);
        let C = () => {
            let {user: e} = (0,
            c.useContext)(v.Il)
              , n = (0,
            d.useRouter)();
            return (0,
            c.useEffect)( () => {
                (null == e ? void 0 : e.role) !== w.i4.ADMIN && n.push("/profile")
            }
            , []),
            (0,
            s.jsx)("section", {
                className: g().section,
                children: (0,
                s.jsx)(j.W2, {
                    className: g().container,
                    children: (null == e ? void 0 : e.role) === w.i4.ADMIN && (0,
                    s.jsx)(r.wo, {})
                })
            })
        }
        ;
        var R = t(2517)
          , I = t.n(R);
        let E = () => (0,
        s.jsx)("section", {
            className: I().section,
            children: (0,
            s.jsx)(j.W2, {
                className: I().container,
                children: (0,
                s.jsx)(r.BT, {})
            })
        });
        var B = t(8954)
          , Q = t.n(B);
        let W = () => {
            let {user: e} = (0,
            c.useContext)(v.Il)
              , n = (0,
            d.useRouter)();
            return (0,
            c.useEffect)( () => {
                (null == e ? void 0 : e.role) !== w.i4.ADMIN && n.push("/profile")
            }
            , []),
            (0,
            s.jsx)("section", {
                className: Q().section,
                children: (0,
                s.jsx)(j.W2, {
                    className: Q().container,
                    children: (null == e ? void 0 : e.role) === w.i4.ADMIN && (0,
                    s.jsx)(r.cx, {})
                })
            })
        }
        ;
        var D = t(2920)
          , P = t(5683)
          , y = t(7435)
          , M = t(601)
          , S = t.n(M);
        let Z = e => {
            let {accounts: n, fetchUser: t, secret: r} = e
              , [i,o] = (0,
            c.useState)(!1)
              , {setPopupDataOrType: a, setSelectedForgottenPaasswordAccount: l} = (0,
            c.useContext)(v.Il)
              , {push: u} = (0,
            d.useRouter)()
              , _ = async e => {
                t && (o(!0),
                r ? (a(w.ZQ.CHANGE_FORGOTTEN_PASSWORD),
                l({
                    secret: r,
                    accountId: e.id,
                    server: e.server
                }),
                document.body.style.overflow = "hidden") : (0,
                y.bs)(e).then( () => {
                    u("/profile"),
                    t()
                }
                ).catch(e => {
                    u("/"),
                    D.Am.error(e.message)
                }
                ),
                o(!1))
            }
            ;
            return (0,
            s.jsx)("section", {
                className: S().section,
                children: (0,
                s.jsx)(j.W2, {
                    className: S().container,
                    children: n ? (0,
                    s.jsxs)("div", {
                        className: S().main,
                        children: [(0,
                        s.jsx)("h3", {
                            className: S().title,
                            children: "Выберите аккаунт"
                        }), n.map(e => (0,
                        s.jsx)(P.zx, {
                            text: e.name,
                            buttonType: w.L$.BIG_PINK,
                            className: S().button,
                            onClickButton: () => _(e),
                            loading: i
                        }, e.id))]
                    }) : (0,
                    s.jsx)(P.B0, {
                        classNames: S().loader
                    })
                })
            })
        }
        ;
        var q = t(5811)
          , F = t.n(q);
        let G = () => {
            let {user: e} = (0,
            c.useContext)(v.Il)
              , n = (0,
            d.useRouter)();
            return (0,
            c.useEffect)( () => {
                (null == e ? void 0 : e.role) !== w.i4.ADMIN && n.push("/profile")
            }
            , []),
            (0,
            s.jsx)("section", {
                className: F().section,
                children: (0,
                s.jsx)(j.W2, {
                    className: F().container,
                    children: (null == e ? void 0 : e.role) === w.i4.ADMIN && (0,
                    s.jsx)(r.xm, {})
                })
            })
        }
        ;
        var H = t(5417)
          , L = t.n(H);
        let T = () => (0,
        s.jsx)("section", {
            className: L().section,
            children: (0,
            s.jsx)(j.W2, {
                className: L().container,
                children: (0,
                s.jsx)(r.cc, {})
            })
        });
        var K = t(9135)
          , O = t.n(K);
        let U = () => (0,
        s.jsx)("section", {
            className: O().main,
            children: (0,
            s.jsx)(j.W2, {
                className: O().container,
                children: (0,
                s.jsx)(r.zu, {})
            })
        })
    },
    601: function(e) {
        e.exports = {
            section: "authCallback_section__hrxYn",
            container: "authCallback_container__Plb6q",
            loader: "authCallback_loader__ZrLnA",
            main: "authCallback_main__s8BDu",
            main_wrapper: "authCallback_main_wrapper__wrjMB",
            title: "authCallback_title__pUo0Z",
            button: "authCallback_button__mFLEw"
        }
    },
    5141: function(e) {
        e.exports = {
            section: "changeNews_section__08xtg",
            container: "changeNews_container__deEZT"
        }
    },
    2517: function(e) {
        e.exports = {
            section: "maps_section__Rzvvl",
            container: "maps_container___ph3b"
        }
    },
    5417: function(e) {
        e.exports = {
            section: "news_section__TvJFL",
            container: "news_container__R3RPA"
        }
    },
    9135: function(e) {
        e.exports = {
            main: "pay_main__qhZ8c",
            container: "pay_container__5RFrd"
        }
    },
    5811: function(e) {
        e.exports = {
            section: "payoutPanel_section__rdzdu",
            container: "payoutPanel_container__HjV5w"
        }
    },
    3710: function(e) {
        e.exports = {
            section: "profile_section__NPoHn",
            container: "profile_container__BOaLM"
        }
    },
    8954: function(e) {
        e.exports = {
            section: "serverPanel_section___6m_Q",
            container: "serverPanel_container__aWR5x"
        }
    },
    4213: function(e) {
        e.exports = {
            section: "shop_section__r5mUx",
            bg: "shop_bg__ben0s"
        }
    },
    3940: function(e) {
        e.exports = {
            section: "terms_section__RoYZs",
            bg: "terms_bg__InJ5e"
        }
    },
    9008: function(e, n, t) {
        e.exports = t(2636)
    }
}, function(e) {
    e.O(0, [774, 888, 179], function() {
        return e(e.s = 2762)
    }),
    _N_E = e.O()
}
]);
